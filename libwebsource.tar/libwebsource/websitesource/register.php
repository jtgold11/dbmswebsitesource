<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once 'Database.php';
require_once 'Account.php';
require_once 'LoginHandle.php';

$alertDisplay = false;
$alertDisplay2 = false;
$alertDisplay3 = false;
$alertDisplay4 = false;
$truthhold = false;
$truthhold2 = false;
$truthhold3 = false;
$truthhold4 = false;
$db = new Database();
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = $_POST["email"];
    $username = $_POST["usn"];
    $password = $_POST["psw"];
    $dob = $_POST["dob"];
    $passRep = $_POST["psw-repeat"];

    $queryStr = "SELECT username FROM User WHERE username='{$username}';";
    $result = $db->sql->query($queryStr);
    if($result->num_rows == 0){
      $truthhold = true;
    }
    else{
      $alertDisplay = true;
    }

    $queryStr2 = "SELECT email FROM User WHERE email='{$email}';";
    $result = $db->sql->query($queryStr2);
    if($result->num_rows == 0){
      $truthhold2 = true;
    }
    else{
      $alertDisplay2 = true;
    }

    if($password  == $passRep){
      $truthhold3 = true;
    }
    else{
      $alertDisplay3 = true;
    }
    if(preg_match("/[A-Z]/", $password)===0) {
		$alertDisplay4 = true;
	}
    else{
      $truthhold4 = true;
    }
	    if($truthhold && $truthhold2 && $truthhold3 && $truthhold4){
        echo "hello";

      $today = getdate();
      $month = $year = $mday = $newmday = "";
      $month =  $today["mon"];
      $year = $today["year"];
      $mday = $today["mday"];

      if($today["mday"] < 10){
      $newmday = "0" . $mday;}
      else{
      $newmday = $mday;}

      $date1 = $year . "-" . $month . "-" . $newmday;

      $queryStr3 = "INSERT INTO User(UID, email, fines, accType, username, password, dob, djoin) VALUES (NULL, '{$email}', 0, 3, '{$username}', '{$password}','{$dob}','{$date1}');";
      $db->sql->query($queryStr3);



    // now that they've signed up, re-direct to login page
    header("Location: /registers.php");
    exit;
  }
}



?>








<!DOCTYPE html>
<html>
  <head>

    <meta charset="UTF-8">
    <title>Welcome</title>
    <meta name="viewport" cotent="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin=
        "anonymous">
    <link rel="stylesheet" href="background.css">


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>



  </head>

  <style>
  .jumbotron {
    background-color: #808080;
    color: #00000;
  }
  </style>

<body>

  <div class="jumbotron text-center">
    <h1>Register</h1>
  </div>
  <div class="alert alert-danger" role="alert" style="display:<?php echo ($alertDisplay?"block":"none"); ?>;">
      Sorry, but your username is already taken.
  </div>
  <div class="alert alert-danger" role="alert" style="display:<?php echo ($alertDisplay2?"block":"none"); ?>;">
        Sorry, but your email is already in use.
    </div>
    <div class="alert alert-danger" role="alert" style="display:<?php echo ($alertDisplay3?"block":"none"); ?>;">
        Sorry, but your passwords do not match.
    </div>
    <div class="alert alert-danger" role="alert" style="display:<?php echo ($alertDisplay4?"block":"none"); ?>;">
        Sorry, but your password must contain an uppercase letter
    </div>

<form action="register.php" method="post" style="border:1px solid #ccc">
  <div class="container">

    <label for="email"><b>Email</b></label>
    <input type="text" class="form-control" placeholder="Enter Email" name="email" required>
    <br>
    <label for="username"><b>Username</b></label>
    <input type="text" class="form-control" placeholder="Enter Username" name="usn" required>
    <br>
    <label for="dob"><b>Date of Birth   (YYYY-MM-DD)</b></label>
    <input type="text" class="form-control" placeholder="Date of birth" name="dob" required>
    <br>
    <label for="psw"><b>Password</b></label>
    <input type="password" class="form-control" placeholder="Enter Password" name="psw" required>
    <br>
    <label for="psw-repeat"><b>Repeat Password</b></label>
    <input type="password" class="form-control" placeholder="Repeat Password" name="psw-repeat" required>
    <br>

    <div class="clearfix">
      <button type="button" onclick="window.location.href = 'index.php';" class="btn btn-primary">Cancel</button>
      <button type="submit" class="btn btn-primary">Register</button>
      <br>
      <br>
    </div>
  </div>
</form>






  </body>

</html>
