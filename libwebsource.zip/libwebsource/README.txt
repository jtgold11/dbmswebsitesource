JACOB GOLD 
Clemson University semester project
Included:
Database dump used for website
Website source code
Important Notes:
I believe for the website to work correctly you must have all the files
and folders in websitesource in your website directory. i.e. you must
extract the files/folders out of "websitesource" and put them into your
website base directory

For comments in the source code of the website. Go to the admin's
folder to look at the comments. all the files are more or less the same
in the source code between user folders but only the admins files are
commentted.