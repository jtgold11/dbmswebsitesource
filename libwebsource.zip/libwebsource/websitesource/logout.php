<?php
require_once 'LoginHandle.php';
 LoginHandler::Logout();

 ?>
